
document.getElementById("addSubjectBtn").addEventListener("click", function () {
    window.location.href = "add_subject.html";
});

document.getElementById("takeAttendanceBtn").addEventListener("click", function () {
    window.location.href = "take_attendance.html";
    
});
